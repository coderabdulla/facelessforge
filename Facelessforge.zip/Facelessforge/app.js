import { AIScriptEngine } from "./ai.js";
import { ImageEngine } from "./image.js";
import { VoiceEngine } from "./voice.js";
import { VideoCompositor } from "./video.js";
import { StorageManager, Utils } from "./storage.js";

class FacelessForgeApp {

    constructor() {

        this.ai = new AIScriptEngine();
        this.image = new ImageEngine();
        this.voice = new VoiceEngine();
        this.video = new VideoCompositor();
        this.storage = new StorageManager();

        this.project = null;
        this.duration = 30;

        this.cacheDOM();
        this.bindEvents();
        this.loadProjects();
        this.renderWelcome();

    }

    cacheDOM() {

        this.generateBtn =
            document.getElementById("btn-generate-pipeline");

        this.playBtn =
            document.getElementById("btn-play-preview");

        this.exportBtn =
            document.getElementById("btn-export-video");

        this.prompt =
            document.getElementById("custom-prompt");

        this.niche =
            document.getElementById("niche-select");

        this.canvas =
            document.getElementById("video-canvas");

        this.sceneList =
            document.getElementById("scenes-list");

        this.projectGrid =
            document.getElementById("projects-grid");

        this.downloadList =
            document.getElementById("downloads-list");

        this.progressBar =
            document.getElementById("render-progress-bar");

        this.progressText =
            document.getElementById("render-progress-percent");

        this.overlay =
            document.getElementById("render-overlay");

    }

    bindEvents() {

        this.generateBtn?.addEventListener(
            "click",
            () => this.generate()
        );

        this.playBtn?.addEventListener(
            "click",
            () => this.preview()
        );

        this.exportBtn?.addEventListener(
            "click",
            () => this.exportVideo()
        );

        document
            .querySelectorAll(".btn-option")
            .forEach(btn => {

                btn.addEventListener("click", () => {

                    document
                        .querySelectorAll(".btn-option")
                        .forEach(b => b.classList.remove("active"));

                    btn.classList.add("active");

                    this.duration =
                        Number(btn.dataset.duration);

                });

            });

    }

    renderWelcome() {

        if (!this.canvas) return;

        const ctx = this.canvas.getContext("2d");

        ctx.fillStyle = "#0F172A";
        ctx.fillRect(0,0,1080,1920);

        ctx.fillStyle = "#8B5CF6";

        ctx.font = "bold 70px Inter";

        ctx.textAlign = "center";

        ctx.fillText(
            "FacelessForge",
            540,
            900
        );

        ctx.fillStyle = "#CBD5E1";

        ctx.font = "40px Inter";

        ctx.fillText(
            "AI Creator Studio",
            540,
            1000
        );

    }

    loadProjects(){

        console.log("Loading Projects...");

    }

}

document.addEventListener("DOMContentLoaded",()=>{

    window.facelessForge =
        new FacelessForgeApp();
async generate() {

    try {

        this.showLoading("Generating AI Script...", 10);

        const prompt =
            this.prompt?.value.trim() || "";

        const niche =
            this.niche?.value || "motivation";

        /* STEP 1 : Generate Script */

        const script =
            await this.ai.generateScript({

                niche,
                durationSec: this.duration,
                customPrompt: prompt

            });

        this.showLoading("Generating Images...", 35);

        /* STEP 2 : Generate Images */

        const scenes =
            await this.image.preloadSceneImages(
                script.scenes
            );

        this.showLoading("Generating Voice...", 65);

        /* STEP 3 : Voice */

        const narration =
            await this.voice.generateVoice(script);

        this.showLoading("Preparing Project...", 85);

        /* STEP 4 : Save Project */

        this.project = {

            id: Date.now(),

            title: script.title || "Untitled",

            niche,

            duration: this.duration,

            createdAt: new Date().toISOString(),

            narration,

            scenes

        };

        this.storage.saveProject(this.project);

        this.renderSceneList();

        this.renderFirstScene();

        this.playBtn.disabled = false;

        this.exportBtn.disabled = false;

        this.showLoading("Completed", 100);

        setTimeout(() => {

            this.hideLoading();

        }, 700);

    }

    catch (err) {

        console.error(err);

        this.hideLoading();

        alert("Failed to generate video.");

    }

}

/* ---------------------------- */

showLoading(title, percent) {

    if (this.overlay)
        this.overlay.classList.remove("hidden");

    if (this.progressBar)
        this.progressBar.style.width =
            percent + "%";

    if (this.progressText)
        this.progressText.textContent =
            percent + "%";

    const status =
        document.getElementById(
            "render-status-title"
        );

    if (status)
        status.textContent = title;

}

/* ---------------------------- */

hideLoading() {

    if (this.overlay)
        this.overlay.classList.add("hidden");

}

/* ---------------------------- */

renderSceneList() {

    if (!this.sceneList) return;

    this.sceneList.innerHTML = "";

    this.project.scenes.forEach((scene, index) => {

        const div =
            document.createElement("div");

        div.className = "scene-item";

        div.innerHTML = `

            <strong>Scene ${index + 1}</strong>

            <p>${scene.text || ""}</p>

        `;

        this.sceneList.appendChild(div);

    });

}

/* ---------------------------- */

renderFirstScene() {

    if (
        !this.project ||
        !this.project.scenes.length
    )
        return;

    const first =
        this.project.scenes[0];

    this.video.renderFrame(

        first.imageElement,

        0,

        "fade"

    );

}
});
/* ========================= */
/* Preview */
/* ========================= */

preview() {

    if (!this.project) return;

    this.video.playPreview(this.project.scenes);

}

/* ========================= */
/* Export */
/* ========================= */

async exportVideo() {

    if (!this.project) return;

    try {

        this.showLoading("Rendering Video...", 20);

        const blob =
            await this.video.exportVideo(
                this.project.scenes
            );

        this.showLoading("Saving File...", 90);

        Utils.downloadFile(
            blob,
            `FacelessForge-${Date.now()}.webm`
        );

        this.addDownload({
            name: `FacelessForge-${Date.now()}.webm`,
            date: new Date().toLocaleString()
        });

        this.showLoading("Done",100);

        setTimeout(()=>{
            this.hideLoading();
        },600);

    } catch(err){

        console.error(err);

        this.hideLoading();

        alert("Video export failed.");

    }

}

/* ========================= */
/* Downloads */
/* ========================= */

addDownload(file){

    if(!this.downloadList) return;

    const item=document.createElement("div");

    item.className="download-item";

    item.innerHTML=`

        <strong>${file.name}</strong>

        <small>${file.date}</small>

    `;

    this.downloadList.prepend(item);

}

/* ========================= */
/* Toast */
/* ========================= */

toast(message){

    let toast=document.createElement("div");

    toast.className="toast";

    toast.textContent=message;

    document.body.appendChild(toast);

    setTimeout(()=>{

        toast.classList.add("show");

    },100);

    setTimeout(()=>{

        toast.remove();

    },3000);

}

/* ========================= */
/* Refresh Projects */
/* ========================= */

refreshProjects(){

    if(!this.projectGrid) return;

    this.projectGrid.innerHTML="";

    const projects=this.storage.getProjects();

    projects.forEach(project=>{

        const card=document.createElement("div");

        card.className="project-card";

        card.innerHTML=`

            <h3>${project.title}</h3>

            <p>${project.niche}</p>

            <small>${project.duration}s</small>

        `;

        this.projectGrid.appendChild(card);

    });

}

/* ========================= */
/* Reset */
/* ========================= */

newProject(){

    this.project=null;

    this.playBtn.disabled=true;

    this.exportBtn.disabled=true;

    this.sceneList.innerHTML="";

    this.renderWelcome();

}

/* ========================= */
/* Storage */
/* ========================= */

saveCurrent(){

    if(!this.project) return;

    this.storage.saveProject(this.project);

    this.refreshProjects();

}

/* ========================= */
/* End Class */
/* ========================= */