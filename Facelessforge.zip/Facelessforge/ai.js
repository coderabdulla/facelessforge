export class AIScriptEngine {
  constructor() {
    this.wordsPerMinute = 145;
    this.nicheTemplates = {
      motivation: {
        title: "Motivation & Personal Growth",
        hooks: [
          "Stop waiting for the perfect moment. The moment is right now.",
          "Nobody is coming to save you. Your life is entirely in your hands."
        ],
        bodyBlocks: [
          "Every single morning you have two choices: continue to sleep with your dreams, or wake up and chase them.",
          "Pain is temporary. Giving up lasts forever.",
          "Consistency is what transforms average effort into extraordinary mastery."
        ],
        callToActions: [
          "Build the discipline today that your future self will thank you for. Follow for daily motivation."
        ],
        visualKeywords: "cinematic dramatic lighting, intense focus, lone runner at sunrise, towering mountain peak, dark moody atmosphere, hyperrealistic 8k"
      },
      business: {
        title: "Business & Entrepreneurship",
        hooks: [
          "99% of people build someone else's dream instead of their own.",
          "Ideas are cheap. Execution is the only currency that matters."
        ],
        bodyBlocks: [
          "Successful entrepreneurs build scalable systems that solve high-value problems.",
          "Focus on value creation first. Wealth is a natural byproduct."
        ],
        callToActions: [
          "Start building your asset library today. Follow for business breakdowns."
        ],
        visualKeywords: "modern glass skyscraper, executive boardroom, futuristic tech office, dark luxury aesthetic, sharp suit, photorealistic 8k"
      },
      finance: {
        title: "Finance & Wealth Secrets",
        hooks: ["The middle class works for money, but the wealthy make money work for them."],
        bodyBlocks: ["Compound interest is the eighth wonder of the world."],
        callToActions: ["Take control of your financial destiny."],
        visualKeywords: "stacks of gold bullion, glowing stock exchange charts, dark luxury vault, 8k cinematic"
      },
      history: {
        title: "Historical Mysteries",
        hooks: ["In 1912, an ancient artifact was discovered that historians still cannot explain."],
        bodyBlocks: ["Deep beneath the desert sands lie forgotten catacombs containing secrets lost to time."],
        callToActions: ["Uncover the secrets of the past. Follow for history breakdowns."],
        visualKeywords: "ancient Egyptian ruins, torchlit stone temple, dusty scroll, 8k"
      },
      horror: {
        title: "Dark Horror",
        hooks: ["If you ever hear whispered voices in the forest at night, never look back."],
        bodyBlocks: ["Shadows began to lengthen as an unnatural cold swept across the silent hallway."],
        callToActions: ["Turn off the lights and lock your doors."],
        visualKeywords: "creepy abandoned house, foggy dark woods, eerie shadowy figure, 8k"
      },
      islamic: {
        title: "Islamic Reflections",
        hooks: ["Remember that every hardship in your life is accompanied by ease."],
        bodyBlocks: ["Trust in the divine timing of your life."],
        callToActions: ["May peace and blessings be upon your day."],
        visualKeywords: "grand mosque architecture, golden hour dome light, 8k"
      },
      quotes: {
        title: "Stoic Philosophy",
        hooks: ["We suffer more often in imagination than in reality."],
        bodyBlocks: ["Control your perceptions and direct your actions properly."],
        callToActions: ["Master your mind today."],
        visualKeywords: "marble statue of Marcus Aurelius, moody lighting, 8k"
      },
      facts: {
        title: "Science Facts",
        hooks: ["There are more trees on Earth than stars in the Milky Way galaxy."],
        bodyBlocks: ["Your body replaces nearly all of its cells every seven years."],
        callToActions: ["Science is mind-blowing. Subscribe for more."],
        visualKeywords: "deep space nebula galaxy, glowing DNA double helix, 8k"
      },
      health: {
        title: "Health & Biohacking",
        hooks: ["What happens to your brain when you fast for 24 hours."],
        bodyBlocks: ["Morning sunlight exposure triggers cortisol release and sets your circadian clock."],
        callToActions: ["Optimize your health today."],
        visualKeywords: "clean athletic movement, serene sunrise, biohacking graphics, 8k"
      },
      education: {
        title: "Educational Insights",
        hooks: ["How a simple trick doubles your memory retention."],
        bodyBlocks: ["Spaced repetition leverages the forgetting curve into long-term memory."],
        callToActions: ["Sharpen your intellect today."],
        visualKeywords: "futuristic digital library, brain neural network glowing, 8k"
      },
      storytelling: {
        title: "Fictional Short Stories",
        hooks: ["The deep sea scanner registered an underwater signal coming from inside the ship."],
        bodyBlocks: ["Whispered conversations revealed a truth that defied everything they had been taught."],
        callToActions: ["Comment below and follow for Part 2."],
        visualKeywords: "cinematic film scene, moody rain slick street, 8k"
      }
    };
  }

  async generateScript({ niche = "motivation", durationSec = 30, customPrompt = "" }) {
    await new Promise((resolve) => setTimeout(resolve, 300));

    const numericDuration = Math.max(10, Number(durationSec) || 30);
    const selectedNiche = this.nicheTemplates[niche] ? niche : "motivation";
    const template = this.nicheTemplates[selectedNiche];

    const targetSceneCount = Math.max(3, Math.round(numericDuration / 6));
    let scenes = [];

    if (customPrompt && customPrompt.trim().length > 5) {
      scenes = this.processCustomPrompt(customPrompt.trim(), targetSceneCount, template);
    } else {
      scenes = this.buildTemplateScenes(template, targetSceneCount);
    }

    const finalScenes = this.adjustSceneDurations(scenes, numericDuration);
    const fullText = finalScenes.map((s) => s.narration).join(" ");

    return {
      success: true,
      niche: selectedNiche,
      nicheTitle: template.title,
      targetDurationSec: numericDuration,
      fullScriptText: fullText,
      scenes: finalScenes
    };
  }

  buildTemplateScenes(template, sceneCount) {
    const scenes = [];
    scenes.push({
      id: 1,
      type: "hook",
      narration: template.hooks[0],
      imagePrompt: `${template.hooks[0]} ${template.visualKeywords}`,
      duration: 5
    });

    for (let i = 0; i < sceneCount - 2; i++) {
      const text = template.bodyBlocks[i % template.bodyBlocks.length];
      scenes.push({
        id: i + 2,
        type: "body",
        narration: text,
        imagePrompt: `${text} ${template.visualKeywords}`,
        duration: 6
      });
    }

    scenes.push({
      id: scenes.length + 1,
      type: "cta",
      narration: template.callToActions[0],
      imagePrompt: `${template.callToActions[0]} ${template.visualKeywords}`,
      duration: 5
    });

    return scenes;
  }

  processCustomPrompt(customPrompt, targetSceneCount, template) {
    const sentences = customPrompt
      .replace(/([.?!])\s*(?=[A-Z0-9])/g, "$1|")
      .split("|")
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    const scenes = [];
    for (let i = 0; i < targetSceneCount; i++) {
      const text = sentences[i % sentences.length] || customPrompt;
      scenes.push({
        id: i + 1,
        type: i === 0 ? "hook" : i === targetSceneCount - 1 ? "cta" : "body",
        narration: text,
        imagePrompt: `${text} ${template.visualKeywords}`,
        duration: 6
      });
    }
    return scenes;
  }

  adjustSceneDurations(scenes, totalDurationSec) {
    const evenDuration = Number((totalDurationSec / scenes.length).toFixed(1));
    return scenes.map((s) => ({ ...s, duration: evenDuration }));
  }
}
