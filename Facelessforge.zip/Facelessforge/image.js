export class ImageEngine {
  constructor() {
    this.baseUrl = "https://image.pollinations.ai/prompt/";
    this.defaultWidth = 1080;
    this.defaultHeight = 1920;
    this.imageCache = new Map();
  }

  getPollinationsUrl(prompt, seed = Math.floor(Math.random() * 1000000)) {
    const encoded = encodeURIComponent(`${prompt}, 9:16 vertical composition, highly detailed, photorealistic 8k`);
    return `${this.baseUrl}${encoded}?width=${this.defaultWidth}&height=${this.defaultHeight}&seed=${seed}&nologo=true`;
  }

  loadImage(url) {
    if (this.imageCache.has(url)) {
      return Promise.resolve(this.imageCache.get(url));
    }

    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        this.imageCache.set(url, img);
        resolve(img);
      };
      img.onerror = () => {
        const fallback = this.createFallbackImage("Image Load Error");
        this.imageCache.set(url, fallback);
        resolve(fallback);
      };
      img.src = url;
    });
  }

  async preloadSceneImages(scenes, options = {}, onProgress = null) {
    if (!Array.isArray(scenes) || scenes.length === 0) return [];

    let completed = 0;
    const total = scenes.length;

    return Promise.all(
      scenes.map(async (scene) => {
        const seed = scene.seed || Math.floor(Math.random() * 1000000);
        const url = this.getPollinationsUrl(scene.imagePrompt || scene.narration, seed);
        const img = await this.loadImage(url);

        completed++;
        if (typeof onProgress === "function") {
          onProgress(completed, total, Math.round((completed / total) * 100));
        }

        return {
          ...scene,
          seed,
          imageUrl: url,
          imageElement: img
        };
      })
    );
  }

  createFallbackImage(label = "Scene Visual") {
    const svg = `
      <svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1920" viewBox="0 0 1080 1920">
        <rect width="1080" height="1920" fill="#090d16"/>
        <text x="540" y="920" font-family="sans-serif" font-size="44" font-weight="bold" fill="#818cf8" text-anchor="middle">FACELESSFORGE 2.0</text>
        <text x="540" y="990" font-family="sans-serif" font-size="28" fill="#94a3b8" text-anchor="middle">${label}</text>
      </svg>
    `.trim();

    const img = new Image();
    img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
    return img;
  }
}
