export class VoiceEngine {
  constructor() {
    this.synth = window.speechSynthesis || null;
    this.voices = [];
    this.selectedVoice = null;
    this.initVoices();
  }

  initVoices() {
    if (!this.synth) return;
    const load = () => {
      this.voices = this.synth.getVoices();
      if (this.voices.length > 0) {
        this.selectedVoice = this.voices.find((v) => v.lang.startsWith("en")) || this.voices[0];
      }
    };
    load();
    if (this.synth.onvoiceschanged !== undefined) {
      this.synth.onvoiceschanged = load;
    }
  }

  speakPreview(text, rate = 1.0, pitch = 1.0) {
    return new Promise((resolve, reject) => {
      if (!this.synth) return reject(new Error("SpeechSynthesis missing"));
      this.synth.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      if (this.selectedVoice) utterance.voice = this.selectedVoice;
      utterance.rate = rate;
      utterance.pitch = pitch;

      utterance.onend = () => resolve();
      utterance.onerror = (err) => reject(err);

      this.synth.speak(utterance);
    });
  }

  generateWordTimestamps(fullText, durationSec, rate = 1.0) {
    if (!fullText) return [];
    const words = fullText.trim().split(/\s+/).filter((w) => w.length > 0);
    const timePerWord = (durationSec / Math.max(0.5, rate)) / words.length;

    let current = 0;
    return words.map((word) => {
      const start = Number(current.toFixed(2));
      current += timePerWord;
      return { word, start, end: Number(current.toFixed(2)) };
    });
  }
}
