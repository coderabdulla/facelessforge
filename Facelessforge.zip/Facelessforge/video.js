import { SubtitleEngine } from "./subtitle.js";

export class VideoCompositor {
  constructor(canvasElement) {
    this.canvas = canvasElement || document.getElementById("video-canvas");
    this.ctx = this.canvas ? this.canvas.getContext("2d") : null;
    this.width = 1080;
    this.height = 1920;

    this.subtitleEngine = new SubtitleEngine();
    this.isPlaying = false;
    this.animationFrameId = null;

    if (this.canvas) {
      this.canvas.width = this.width;
      this.canvas.height = this.height;
    }
  }

  renderFrame(image, sceneProgress, transitionStyle, timedWords = [], sceneTime = 0) {
    if (!this.ctx) return;
    const { ctx, width, height } = this;

    ctx.clearRect(0, 0, width, height);
    ctx.save();

    const scale = 1.0 + sceneProgress * 0.15;
    ctx.translate(width / 2, height / 2);
    ctx.scale(scale, scale);

    if (image && image.complete && image.naturalWidth > 0) {
      ctx.drawImage(image, -width / 2, -height / 2, width, height);
    } else {
      ctx.fillStyle = "#0f172a";
      ctx.fillRect(-width / 2, -height / 2, width, height);
    }

    ctx.restore();

    if (timedWords.length > 0) {
      this.subtitleEngine.renderSubtitle(ctx, timedWords, sceneTime);
    }
  }

  playPreview(scenes, options = {}, onProgress = null) {
    return new Promise((resolve) => {
      if (!scenes || scenes.length === 0) return resolve();
      this.stop();
      this.isPlaying = true;

      const totalDuration = scenes.reduce((sum, s) => sum + s.duration, 0);
      let startTime = null;

      const scenesWithTimings = scenes.map((scene) => ({
        ...scene,
        timedWords: this.subtitleEngine.generateTimedWords(scene.narration, scene.duration)
      }));

      const animate = (timestamp) => {
        if (!this.isPlaying) return resolve();
        if (!startTime) startTime = timestamp;

        const elapsedTimeSec = (timestamp - startTime) / 1000;
        if (elapsedTimeSec >= totalDuration) {
          this.isPlaying = false;
          return resolve();
        }

        let accumulated = 0;
        let activeScene = scenesWithTimings[0];
        let sceneTime = 0;

        for (let sc of scenesWithTimings) {
          if (elapsedTimeSec >= accumulated && elapsedTimeSec < accumulated + sc.duration) {
            activeScene = sc;
            sceneTime = elapsedTimeSec - accumulated;
            break;
          }
          accumulated += sc.duration;
        }

        this.renderFrame(
          activeScene.imageElement,
          sceneTime / activeScene.duration,
          options.transitionStyle,
          activeScene.timedWords,
          sceneTime
        );

        if (typeof onProgress === "function") {
          onProgress(Math.round((elapsedTimeSec / totalDuration) * 100));
        }

        this.animationFrameId = requestAnimationFrame(animate);
      };

      this.animationFrameId = requestAnimationFrame(animate);
    });
  }

  exportVideo(scenes, options = {}, onProgress = null) {
    return new Promise(async (resolve, reject) => {
      if (!this.canvas || !scenes.length) return reject(new Error("Canvas unavailable"));

      const stream = this.canvas.captureStream(60);
      const recorder = new MediaRecorder(stream, { mimeType: "video/webm" });
      const chunks = [];

      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = () => resolve(new Blob(chunks, { type: "video/webm" }));

      recorder.start(100);
      await this.playPreview(scenes, options, onProgress);
      recorder.stop();
    });
  }

  stop() {
    this.isPlaying = false;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }
}
