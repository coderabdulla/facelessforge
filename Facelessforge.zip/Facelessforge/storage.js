export class StorageManager {
  constructor() {
    this.PROJECTS_KEY = "facelessforge_projects";
    this.EXPORTS_KEY = "facelessforge_exports";
  }

  getProjects() {
    try {
      return JSON.parse(localStorage.getItem(this.PROJECTS_KEY)) || [];
    } catch {
      return [];
    }
  }

  saveProject(project) {
    const projects = this.getProjects();
    const serializable = {
      ...project,
      id: project.id || `proj_${Date.now()}`,
      scenes: (project.scenes || []).map(({ imageElement, ...rest }) => rest)
    };
    projects.unshift(serializable);
    localStorage.setItem(this.PROJECTS_KEY, JSON.stringify(projects));
  }

  deleteProject(id) {
    const projects = this.getProjects().filter((p) => p.id !== id);
    localStorage.setItem(this.PROJECTS_KEY, JSON.stringify(projects));
  }

  getExportRecords() {
    try {
      return JSON.parse(localStorage.getItem(this.EXPORTS_KEY)) || [];
    } catch {
      return [];
    }
  }

  saveExportRecord(record) {
    const records = this.getExportRecords();
    records.unshift({ ...record, createdAt: new Date().toISOString() });
    localStorage.setItem(this.EXPORTS_KEY, JSON.stringify(records.slice(0, 20)));
  }

  clearExportRecords() {
    localStorage.removeItem(this.EXPORTS_KEY);
  }
}

export class Utils {
  static downloadFile(blob, fileName) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  }
}
